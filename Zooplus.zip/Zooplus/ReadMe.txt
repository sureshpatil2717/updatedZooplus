Read.ME
Prerequistie For Appium Android java
Step1:Downaload java 1.8
Step2:Download Android studio
Step3:Download Sdk API 30 in AVD Mangaer
Step4:Download Ecllipse
Step5:Install TestNg From Ecllipse market
Step5:Download Appium

Next Level;

Step1:Download frame work from git hub link.
step2:launch Emulator
step3:Take apk from frame work & hit "adb install & apk path" in command prompt.
Step4:Go to Src/test/java & go to Runner pacakge
Step5:Click on Run Command