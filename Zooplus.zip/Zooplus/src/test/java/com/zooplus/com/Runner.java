package com.zooplus.com;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features = "features", glue = "stepdefination", plugin = {"pretty", "html:target/Destination"})
public class Runner {

}
