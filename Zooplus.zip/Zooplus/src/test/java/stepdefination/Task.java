package stepdefination;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Task {
	
	public static URL url;
	 public static DesiredCapabilities capabilities;
	 public static AndroidDriver<MobileElement> driver;
	
	@Given("I launch the android app")
	public void i_launch_the_android_app() throws MalformedURLException 
	{
		 final String URL_STRING = "http://0.0.0.0:4723/wd/hub";
		   url = new URL(URL_STRING);
		//3
		   capabilities = new DesiredCapabilities();
		   capabilities.setCapability("deviceName","Android Device");
		   //capabilities.setCapability(MobileCapabilityType.APP, System.getProperty("user.dir")+"\\apk\\app-mock-debug.apk");
          //capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
		  // capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		   capabilities.setCapability(MobileCapabilityType.UDID,"emulator-5554");
		   capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,"11");
		   capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
		   capabilities.setCapability("appPackage","com.example.android.architecture.blueprints.master.mock");
		   capabilities.setCapability("appActivity","com.example.android.architecture.blueprints.todoapp.tasks.TasksActivity");
		   capabilities.setCapability("automationName", "UiAutomator2");
		   
		   
		   
		   //4
		   driver = new AndroidDriver<MobileElement>(url, capabilities);
	       driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    
	}

	@When("I click on plus")
	public void i_click_on_plus()
	{
		 driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_fab")).click();
	}

	@When("I Enter Task1 &Task2 Title")
	public void i_enter_task1_task2_title() 
	{
		   
		    //6
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_title_edit_text")).sendKeys("Task1");
		    //7
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_description_edit_text")).sendKeys("First Task Created suceesfully");
		    //8
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/save_task_fab")).click();
			   
			
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_fab")).click();
		    //9
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_title_edit_text")).sendKeys("Task2");
		    //10
		    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_description_edit_text")).sendKeys("First Task two Created suceesfully");
		    
	}

	@When("I click On Save Button")
	public void i_click_on_save_button()
	{
		driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/save_task_fab")).click();
		
	}

	@When("I click on Menu")
	public void i_click_on_menu() {
		 driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/complete_checkbox")).click();
	}

	@Then("I verify Statics")
	public void i_verify_statics() 
	{
		    
		    
		   driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]")).click();
		    
		   driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/statistics_fragment_dest")).click();
		    
		   String Actual= driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/stats_active_text")).getText();
		   System.out.println(Actual);
		   Assert.assertEquals(Actual,"Active tasks: 50.0%");
		   
		   String Actual1= driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/stats_completed_text")).getText();
		   Assert.assertEquals(Actual1,"Completed tasks: 50.0%" );
		   System.out.println(Actual1);
	   
	}

	@When("I click on more Button")
	public void i_click_on_more_button() 
	{
		driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]")).click();
		   
		driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/tasks_fragment_dest")).click();
		   
		  
	   
	}

	@When("I clear completed Task1")
	public void i_clear_completed_task1() 
	{
		 driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"More options\"]")).click();
		 driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/title")).click();
	    
	}

	@Then("I Verify Task1 is deleted")
	public void i_verify_task1_is_deleted() {
		String s=driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/title_text")).getText();
		   System.out.println(s);
		  
		   if(s.contains("Task2"))
		   {
			  System.out.println("completed Task is deleted"); 
		   }
		   else
		   {
			   System.out.println("completed Task is not deleted");
		   }
	}

}
