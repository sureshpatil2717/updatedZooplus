package linearscripting;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Sample {
	public static URL url;
	 public static DesiredCapabilities capabilities;
	 public static AndroidDriver<MobileElement> driver;
	 //1
	 public static void main(String[] args) throws MalformedURLException  {
	   //2
	   final String URL_STRING = "http://0.0.0.0:4723/wd/hub";
	   url = new URL(URL_STRING);
	//3
	   capabilities = new DesiredCapabilities();
	   capabilities.setCapability("deviceName","Android Device");
	   //capabilities.setCapability(MobileCapabilityType.APP, System.getProperty("user.dir")+"\\apk\\app-mock-debug.apk");
//	    capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
	  // capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
	   capabilities.setCapability(MobileCapabilityType.UDID,"emulator-5554");
	   capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,"11");
	   capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
	   capabilities.setCapability("appPackage","com.example.android.architecture.blueprints.master.mock");
	   capabilities.setCapability("appActivity","com.example.android.architecture.blueprints.todoapp.tasks.TasksActivity");
	   capabilities.setCapability("automationName", "UiAutomator2");
	   
	   
	   
	   //4
	   driver = new AndroidDriver<MobileElement>(url, capabilities);
    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    //5
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_fab")).click();
    //6
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_title_edit_text")).sendKeys("Task1");
    //7
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_description_edit_text")).sendKeys("First Task Created suceesfully");
    //8
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/save_task_fab")).click();
	   
	   ///////////////////////////////////////////////
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_fab")).click();
    //9
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_title_edit_text")).sendKeys("Task2");
    //10
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/add_task_description_edit_text")).sendKeys("First Task two Created suceesfully");
    //11
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/save_task_fab")).click();
	//12
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/complete_checkbox")).click();
    
    //13
    driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]")).click();
    
    driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/statistics_fragment_dest")).click();
    
   String Actual= driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/stats_active_text")).getText();
   System.out.println(Actual);
   
   String Expected= driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/stats_completed_text")).getText();
   System.out.println(Expected);
   
   driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]")).click();
   
   driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/tasks_fragment_dest")).click();
   
   driver.findElement(By.xpath("//android.widget.ImageView[@content-desc=\"More options\"]")).click();
   
   driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/title")).click();
   
   String s=driver.findElement(By.id("com.example.android.architecture.blueprints.master.mock:id/title_text")).getText();
   System.out.println(s);
  
   if(s.contains("Task2"))
   {
	  System.out.println("completed Task is deleted"); 
   }
   else
   {
	   System.out.println("completed Task is not deleted");
   }

  
   
	 }
}
